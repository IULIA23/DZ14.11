//
//  MyView.swift
//  DZ_ANDREEVa
//
//  Created by Юлия Андреева on 14.11.2020.
//  Copyright © 2020 IULIIA ANDREEVA. All rights reserved.
//

import UIKit

class MyView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
