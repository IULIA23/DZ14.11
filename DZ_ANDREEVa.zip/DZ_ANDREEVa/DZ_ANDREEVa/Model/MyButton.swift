//
//  MyButton.swift
//  DZ_ANDREEVa
//
//  Created by Юлия Андреева on 14.11.2020.
//  Copyright © 2020 IULIIA ANDREEVA. All rights reserved.
//

import UIKit

class MyButton: UIControl {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */


    override init(frame: CGRect) {
        super.init(frame: frame)

        self.backgroundColor = .red
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override var isHighlighted: Bool {
        didSet {
            self.backgroundColor = self.isHighlighted ? .green : .red
        }
    }

    override func beginTracking(_ touch: UITouch, with event: UIEvent?) -> Bool {
        return true
        
    }
    
    override func continueTracking(_ touch: UITouch, with event: UIEvent?) -> Bool {
        return true
    }
    override func  endTracking(_ touch: UITouch?, with event: UIEvent?) {
        
    }

    override func cancelTracking(with event: UIEvent?) {
    }
}
